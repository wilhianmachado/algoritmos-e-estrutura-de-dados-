# tests/test_fila.py
import unittest
from src.fila import FilaEncadeada


class TestFilaEncadeada(unittest.TestCase):

    def setUp(self):
        self.fila = FilaEncadeada()

    def test_fila_inicia_vazia(self):
        self.assertTrue(self.fila.esta_vazia())
        self.assertEqual(len(self.fila), 0)

    def test_enfileirar_e_frente(self):
        self.fila.enfileirar("Item 1")
        self.assertFalse(self.fila.esta_vazia())
        self.assertEqual(self.fila.frente(), "Item 1")
        self.assertEqual(len(self.fila), 1)

    def test_ordem_fifo(self):
        self.fila.enfileirar("A")
        self.fila.enfileirar("B")
        self.fila.enfileirar("C")

        self.assertEqual(self.fila.desenfileirar(), "A")
        self.assertEqual(self.fila.desenfileirar(), "B")
        self.assertEqual(self.fila.desenfileirar(), "C")
        self.assertTrue(self.fila.esta_vazia())

    def test_desenfileirar_vazia(self):
        with self.assertRaises(IndexError):
            self.fila.desenfileirar()


if __name__ == "__main__":
    unittest.main()