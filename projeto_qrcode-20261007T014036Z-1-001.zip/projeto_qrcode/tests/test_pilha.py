import unittest
from src.pilha import PilhaEncadeada


class TestPilhaEncadeada(unittest.TestCase):

    def setUp(self):
        self.pilha = PilhaEncadeada()

    def test_pilha_inicia_vazia(self):
        self.assertTrue(self.pilha.esta_vazia())
        self.assertEqual(len(self.pilha), 0)

    def test_push_e_topo(self):
        self.pilha.push("Ação 1")
        self.assertFalse(self.pilha.esta_vazia())
        self.assertEqual(self.pilha.topo(), "Ação 1")
        self.assertEqual(len(self.pilha), 1)

    def test_ordem_lifo(self):
        self.pilha.push("Primeiro")
        self.pilha.push("Segundo")
        self.pilha.push("Terceiro")

        # Na pilha, o último a entrar é o primeiro a sair
        self.assertEqual(self.pilha.pop(), "Terceiro")
        self.assertEqual(self.pilha.pop(), "Segundo")
        self.assertEqual(self.pilha.pop(), "Primeiro")
        self.assertTrue(self.pilha.esta_vazia())

    def test_pop_pilha_vazia_lanca_excecao(self):
        with self.assertRaises(IndexError):
            self.pilha.pop()


if __name__ == "__main__":
    unittest.main()