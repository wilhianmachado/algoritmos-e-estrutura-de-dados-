from typing import Any, Optional
from src.no import Node


class PilhaEncadeada:
    """TAD Pilha implementada sobre nós encadeados (LIFO).

    Complexidade assintótica:
      - push (empilhar): O(1)
      - pop (desempilhar): O(1)
      - topo (peek): O(1)
      - esta_vazia: O(1)
    """

    def __init__(self):
        self._topo: Optional[Node] = None
        self._tamanho: int = 0

    def push(self, dado: Any) -> None:
        """Insere um elemento no topo da pilha (push)."""
        novo_no = Node(dado)
        novo_no.proximo = self._topo
        self._topo = novo_no
        self._tamanho += 1

    def pop(self) -> Any:
        """Remove e devolve o elemento do topo da pilha (pop).

        Gera IndexError se a pilha estiver vazia.
        """
        if self.esta_vazia():
            raise IndexError("Não é possível desempilhar de uma pilha vazia.")

        removido = self._topo
        self._topo = self._topo.proximo
        self._tamanho -= 1
        return removido.dado

    def topo(self) -> Any:
        """Consulta o elemento no topo sem o remover."""
        if self.esta_vazia():
            raise IndexError("A pilha está vazia.")
        return self._topo.dado

    def esta_vazia(self) -> bool:
        """Verifica se a pilha está vazia."""
        return self._topo is None

    def __len__(self) -> int:
        return self._tamanho

    def __repr__(self) -> str:
        itens = []
        atual = self._topo
        while atual is not None:
            itens.append(str(atual.dado))
            atual = atual.proximo
        return "Topo -> " + " -> ".join(itens)