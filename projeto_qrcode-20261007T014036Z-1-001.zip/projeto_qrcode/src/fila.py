# src/fila.py
from typing import Any, Optional
from src.no import Node


class FilaEncadeada:
    """TAD Fila implementada sobre lista simplesmente encadeada.

    Complexidade:
      - enfileirar: O(1)
      - desenfileirar: O(1)
      - frente: O(1)
      - esta_vazia: O(1)
    """

    def __init__(self):
        self._inicio: Optional[Node] = None
        self._fim: Optional[Node] = None
        self._tamanho: int = 0

    def enfileirar(self, dado: Any) -> None:
        """Insere um novo elemento no final da fila."""
        novo_no = Node(dado)
        if self.esta_vazia():
            self._inicio = novo_no
            self._fim = novo_no
        else:
            self._fim.proximo = novo_no
            self._fim = novo_no
        self._tamanho += 1

    def desenfileirar(self) -> Any:
        """Remove e devolve o elemento no início da fila."""
        if self.esta_vazia():
            raise IndexError("Não é possível desenfileirar de uma fila vazia.")

        no_removido = self._inicio
        self._inicio = self._inicio.proximo
        self._tamanho -= 1

        if self._inicio is None:
            self._fim = None

        return no_removido.dado

    def frente(self) -> Any:
        """Consulta o primeiro elemento sem o remover."""
        if self.esta_vazia():
            raise IndexError("A fila está vazia.")
        return self._inicio.dado

    def esta_vazia(self) -> bool:
        """Verifica se a fila está vazia."""
        return self._inicio is None

    def __len__(self) -> int:
        return self._tamanho

    def __repr__(self) -> str:
        itens = []
        atual = self._inicio
        while atual is not None:
            itens.append(str(atual.dado))
            atual = atual.proximo
        return "Fila: [" + " -> ".join(itens) + "]"