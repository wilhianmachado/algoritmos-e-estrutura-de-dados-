import os
import qrcode
from src.fila import FilaEncadeada
from src.pilha import PilhaEncadeada


class PedidoQRCode:
    """Representa um pedido de geração de QR Code."""

    def __init__(self, conteudo: str, nome_arquivo: str):
        self.conteudo = conteudo
        # Garante a extensão .png no nome do ficheiro
        if not nome_arquivo.lower().endswith('.png'):
            nome_arquivo += '.png'
        self.nome_arquivo = nome_arquivo

    def __repr__(self) -> str:
        return f"Pedido({self.nome_arquivo} -> {self.conteudo})"


class GerenciadorQRCode:
    """Coordena o processamento em lote e histórico usando Fila e Pilha."""

    def __init__(self, pasta_saida: str = "saidas"):
        self.pasta_saida = pasta_saida
        self.fila_pendentes = FilaEncadeada()
        self.historico_gerados = PilhaEncadeada()

        # Cria a pasta de saída se ainda não existir
        os.makedirs(self.pasta_saida, exist_ok=True)

    def adicionar_pedido(self, conteudo: str, nome_arquivo: str) -> None:
        """Enfileira um novo pedido na fila (FIFO)."""
        pedido = PedidoQRCode(conteudo, nome_arquivo)
        self.fila_pendentes.enfileirar(pedido)
        print(f"[+] Pedido '{pedido.nome_arquivo}' adicionado à fila.")

    def processar_proximo(self) -> bool:
        """Processa um único pedido do início da fila."""
        if self.fila_pendentes.esta_vazia():
            print("[-] Nenhum pedido pendente na fila.")
            return False

        pedido: PedidoQRCode = self.fila_pendentes.desenfileirar()
        caminho_completo = os.path.join(self.pasta_saida, pedido.nome_arquivo)

        # Gera a imagem do QR Code
        imagem = qrcode.make(pedido.conteudo)
        imagem.save(caminho_completo)

        # Empilha no histórico para permitir Undo (LIFO)
        self.historico_gerados.push(pedido)
        print(f"[OK] Gerado com sucesso: {caminho_completo}")
        return True

    def processar_todos(self) -> int:
        """Processa todos os itens da fila até esvaziar."""
        total = 0
        if self.fila_pendentes.esta_vazia():
            print("[-] A fila já está vazia.")
            return total

        print("\n--- A processar fila de pedidos ---")
        while not self.fila_pendentes.esta_vazia():
            self.processar_proximo()
            total += 1
        print(f"--- Concluído: {total} QR Code(s) gerado(s) ---\n")
        return total

    def desfazer_ultimo(self) -> bool:
        """Desfaz a última geração (pop na pilha) e elimina o ficheiro criado."""
        if self.historico_gerados.esta_vazia():
            print("[-] Não há operações no histórico para desfazer.")
            return False

        ultimo_pedido: PedidoQRCode = self.historico_gerados.pop()
        caminho_completo = os.path.join(
            self.pasta_saida, ultimo_pedido.nome_arquivo
        )

        if os.path.exists(caminho_completo):
            try:
                os.remove(caminho_completo)
                print(
                    f"[!] Desfazer concluído: ficheiro '{ultimo_pedido.nome_arquivo}' eliminado."
                )
            except OSError as erro:
                print(f"[ERRO] Falha ao eliminar ficheiro: {erro}")
        else:
            print(
                f"[!] Registo removido do histórico, mas o ficheiro não foi encontrado em disco."
            )
        return True