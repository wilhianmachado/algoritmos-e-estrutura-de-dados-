# src/no.py
from typing import Any, Optional


class Node:
    """Nó fundamental para estruturas dinâmicas encadeadas."""

    def __init__(self, dado: Any):
        self.dado: Any = dado
        self.proximo: Optional['Node'] = None

    def __repr__(self) -> str:
        return f"Node({self.dado})"