import sys
from src.gerenciador import GerenciadorQRCode


def menu():
    app = GerenciadorQRCode()

    while True:
        print("\n" + "=" * 45)
        print("    SISTEMA DE GERAÇÃO DE QR CODE (AED I)   ")
        print("=" * 45)
        print(f" Itens na fila: {len(app.fila_pendentes)}")
        print(f" Itens no histórico (gerados): {len(app.historico_gerados)}")
        print("-" * 45)
        print(" 1. Adicionar pedido de QR Code à Fila (FIFO)")
        print(" 2. Processar próximo pedido da Fila")
        print(" 3. Processar TODOS os pedidos da Fila")
        print(" 4. Desfazer último QR Code gerado (Pilha - LIFO)")
        print(" 5. Sair")
        print("=" * 45)

        opcao = input("Escolha uma opção (1-5): ").strip()

        if opcao == "1":
            conteudo = input(
                "Digite o link ou texto para o QR Code: "
            ).strip()
            if not conteudo:
                print("[!] Conteúdo não pode ser vazio.")
                continue
            nome = input(
                "Digite o nome do ficheiro (ex: convite.png): "
            ).strip()
            if not nome:
                print("[!] Nome do ficheiro não pode ser vazio.")
                continue
            app.adicionar_pedido(conteudo, nome)

        elif opcao == "2":
            app.processar_proximo()

        elif opcao == "3":
            app.processar_todos()

        elif opcao == "4":
            app.desfazer_ultimo()

        elif opcao == "5":
            print("\nA encerrar o programa...")
            sys.exit(0)

        else:
            print("[!] Opção inválida. Tente novamente.")


if __name__ == "__main__":
    menu()